"""
fontbuild

A collection of font production tools written for FontLab
"""
version = "0.1"