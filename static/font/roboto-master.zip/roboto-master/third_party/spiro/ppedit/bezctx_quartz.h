bezctx *new_bezctx_quartz(void);

CGMutablePathRef
bezctx_to_quartz(bezctx *bc);
