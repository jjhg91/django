
bezctx *new_bezctx_libart(void);

ArtBpath *
bezctx_to_bpath(bezctx *bc);
